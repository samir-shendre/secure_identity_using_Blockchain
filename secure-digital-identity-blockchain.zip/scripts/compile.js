// Compiles contracts/IdentityRegistry.sol using the pure-JS `solc` npm
// package (registry.npmjs.org), instead of Hardhat's default compiler
// downloader (binaries.soliditylang.org), which is blocked in this sandbox.
// Output: artifacts-solc/IdentityRegistry.json { abi, bytecode }

const fs = require("fs");
const path = require("path");
const solc = require("solc");

const ROOT = path.join(__dirname, "..");
const CONTRACTS_DIR = path.join(ROOT, "contracts");
const OUT_DIR = path.join(ROOT, "artifacts-solc");

function findImport(importPath) {
  // Resolve @openzeppelin/... and local imports from node_modules / contracts dir
  const candidates = [
    path.join(ROOT, "node_modules", importPath),
    path.join(CONTRACTS_DIR, importPath)
  ];
  for (const c of candidates) {
    if (fs.existsSync(c)) {
      return { contents: fs.readFileSync(c, "utf8") };
    }
  }
  return { error: `File not found: ${importPath}` };
}

function main() {
  const contractName = "IdentityRegistry.sol";
  const source = fs.readFileSync(path.join(CONTRACTS_DIR, contractName), "utf8");

  const input = {
    language: "Solidity",
    sources: { [contractName]: { content: source } },
    settings: {
      optimizer: { enabled: true, runs: 200 },
      evmVersion: "cancun",
      outputSelection: {
        "*": { "*": ["abi", "evm.bytecode.object", "evm.deployedBytecode.object"] }
      }
    }
  };

  const output = JSON.parse(solc.compile(JSON.stringify(input), { import: findImport }));

  if (output.errors) {
    let hasError = false;
    for (const err of output.errors) {
      console.log(err.formattedMessage || err.message);
      if (err.severity === "error") hasError = true;
    }
    if (hasError) {
      process.exit(1);
    }
  }

  const compiled = output.contracts[contractName]["IdentityRegistry"];

  if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });
  fs.writeFileSync(
    path.join(OUT_DIR, "IdentityRegistry.json"),
    JSON.stringify(
      {
        abi: compiled.abi,
        bytecode: "0x" + compiled.evm.bytecode.object,
        deployedBytecode: "0x" + compiled.evm.deployedBytecode.object
      },
      null,
      2
    )
  );

  console.log("Compiled OK -> artifacts-solc/IdentityRegistry.json");
}

main();
