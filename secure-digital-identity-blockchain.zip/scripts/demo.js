// End-to-end walkthrough of the architecture in Fig. 1–4 of the paper:
//   Issuer authorization -> attribute hashing (Eq. 1) -> issuer signs ->
//   on-chain registration (Eq. 3) -> verifier checks proof (Fig. 3) ->
//   tamper detection -> revocation -> re-verification.
//
// Run with:  node scripts/demo.js

const hre = require("hardhat");
const { ethers } = hre;
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const artifact = JSON.parse(
  fs.readFileSync(path.join(__dirname, "..", "artifacts-solc", "IdentityRegistry.json"), "utf8")
);

function commitmentHash(attributes, salt) {
  return ethers.solidityPackedKeccak256(["string", "bytes32"], [JSON.stringify(attributes), salt]);
}

function randomSalt() {
  return "0x" + crypto.randomBytes(32).toString("hex");
}

function didFor(holderAddress, nonce) {
  return ethers.keccak256(ethers.solidityPacked(["address", "uint256"], [holderAddress, nonce]));
}

async function signAsIssuer(issuerSigner, did, hash, holderAddress) {
  const digest = ethers.keccak256(
    ethers.solidityPacked(["bytes32", "bytes32", "address"], [did, hash, holderAddress])
  );
  return issuerSigner.signMessage(ethers.getBytes(digest));
}

async function main() {
  const [registrar, issuer, holder, verifierBank, attacker] = await ethers.getSigners();

  console.log("== Deploying IdentityRegistry ==");
  const factory = new ethers.ContractFactory(artifact.abi, artifact.bytecode, registrar);
  const registry = await factory.deploy(registrar.address);
  await registry.waitForDeployment();
  console.log("Deployed at:", await registry.getAddress());

  console.log("\n== Step 1: Registrar authorizes an issuer (e.g., a university) ==");
  await (await registry.connect(registrar).authorizeIssuer(issuer.address)).wait();
  console.log("Issuer authorized:", issuer.address);

  console.log("\n== Step 2: Holder assembles identity attributes off-chain (Section IV-A) ==");
  const attributes = { name: "Asha Verma", dob: "1998-03-12", studentId: "UID-88213" };
  const salt = randomSalt();
  const hash = commitmentHash(attributes, salt); // Eq. (1)
  console.log("Attributes (kept off-chain):", attributes);
  console.log("Commitment hash H (on-chain):", hash);

  console.log("\n== Step 3: DID generation + issuer signs the commitment (Fig. 4) ==");
  const did = didFor(holder.address, 1);
  const signature = await signAsIssuer(issuer, did, hash, holder.address);
  console.log("DID:", did);
  console.log("Issuer signature:", signature);

  console.log("\n== Step 4: Holder submits registration transaction (Eq. 3 written on-chain) ==");
  const tx = await registry.connect(holder).registerIdentity(did, hash, signature);
  const receipt = await tx.wait();
  console.log("Registered in block", receipt.blockNumber, "gas used:", receipt.gasUsed.toString());

  console.log("\n== Step 5: A relying party (bank) verifies the credential (Fig. 3) ==");
  const isValid = await registry.connect(verifierBank).verifyIdentity(did, hash);
  console.log("Verifier sees valid =", isValid);

  console.log("\n== Step 6: Tamper check — an attacker presents a forged hash ==");
  const forgedHash = commitmentHash({ ...attributes, name: "Mallory" }, salt);
  const tamperedValid = await registry.verifyIdentity(did, forgedHash);
  console.log("Verifier sees valid (forged attributes) =", tamperedValid);

  console.log("\n== Step 7: Holder revokes the credential (e.g., device/key compromise) ==");
  await (await registry.connect(holder).revokeIdentity(did)).wait();
  const stillValid = await registry.verifyIdentity(did, hash);
  console.log("Verifier sees valid AFTER revocation =", stillValid);

  console.log("\n== Step 8: An unrelated third party cannot revoke someone else's DID ==");
  try {
    await registry.connect(attacker).revokeIdentity(didFor(holder.address, 1));
  } catch (e) {
    console.log("Attacker revoke correctly reverted:", e.reason || e.shortMessage || e.message);
  }

  console.log("\nDemo complete.");
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
