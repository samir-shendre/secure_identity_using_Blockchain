// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts/utils/cryptography/MessageHashUtils.sol";

/// @title IdentityRegistry
/// @notice On-chain component of the "Secure Digital Identity Management Using
///         Blockchain Technology" architecture. Implements the Smart Contract
///         layer described in Section V of the paper: identity registration,
///         revocation, and verification. Only the commitment hash H = H(A1‖A2‖
///         …‖An‖salt) (Eq. 1), never raw identity attributes, is ever written
///         on-chain. The on-chain record R = <DID, H, timestamp, status>
///         corresponds to Eq. 3, and registration requires a valid issuer
///         signature, corresponding to the Verify(PKissuer, H, Sig) check in
///         Eq. 2.
contract IdentityRegistry is Ownable {
    using ECDSA for bytes32;
    using MessageHashUtils for bytes32;

    enum Status {
        None,
        Active,
        Revoked
    }

    struct Credential {
        bytes32 commitmentHash; // H  — Eq. (1)
        address issuer; // recovered signer of the issuance signature
        address holder; // wallet address that owns/controls the DID
        uint64 timestamp; // block time of registration — Eq. (3)
        Status status; // Active | Revoked          — Eq. (3)
    }

    /// @dev did => credential record (Eq. 3: R = <DID, H, timestamp, status>)
    mapping(bytes32 => Credential) private _records;

    /// @dev Authorized issuers (e.g., banks, government bodies, universities).
    mapping(address => bool) public isAuthorizedIssuer;

    event IssuerAuthorized(address indexed issuer);
    event IssuerRevoked(address indexed issuer);

    event IdentityRegistered(
        bytes32 indexed did,
        bytes32 indexed commitmentHash,
        address indexed issuer,
        address holder,
        uint64 timestamp
    );

    event IdentityRevoked(bytes32 indexed did, address indexed revokedBy, uint64 timestamp);

    error IssuerNotAuthorized(address issuer);
    error DidAlreadyRegistered(bytes32 did);
    error DidNotRegistered(bytes32 did);
    error AlreadyRevoked(bytes32 did);
    error NotAuthorizedToRevoke(bytes32 did, address caller);
    error InvalidIssuerSignature();

    constructor(address initialOwner) Ownable(initialOwner) {}

    // ---------------------------------------------------------------
    // Issuer governance (Registrar role — Section V, Smart Contract layer)
    // ---------------------------------------------------------------

    function authorizeIssuer(address issuer) external onlyOwner {
        isAuthorizedIssuer[issuer] = true;
        emit IssuerAuthorized(issuer);
    }

    function revokeIssuer(address issuer) external onlyOwner {
        isAuthorizedIssuer[issuer] = false;
        emit IssuerRevoked(issuer);
    }

    // ---------------------------------------------------------------
    // Registration — Fig. 4 "Store credential hash on blockchain ledger"
    // ---------------------------------------------------------------

    /// @notice Registers a new decentralized identity commitment on-chain.
    /// @dev Mirrors the algorithm in Fig. 4: the holder submits a DID and the
    ///      commitment hash H (Eq. 1) produced off-chain, together with an
    ///      issuer signature over (did, commitmentHash, holder). The contract
    ///      recovers the signer and rejects the transaction unless the signer
    ///      is an authorized issuer — this is the on-chain equivalent of
    ///      Verify(PKissuer, H, Sig) in Eq. (2).
    /// @param did Decentralized identifier of the holder (keccak256-derived off-chain).
    /// @param commitmentHash H — the salted hash of the identity attributes; never the raw data.
    /// @param issuerSignature ECDSA signature by the issuer over keccak256(did, commitmentHash, holder).
    function registerIdentity(
        bytes32 did,
        bytes32 commitmentHash,
        bytes calldata issuerSignature
    ) external {
        if (_records[did].status != Status.None) {
            revert DidAlreadyRegistered(did);
        }

        address holder = msg.sender;
        bytes32 digest = keccak256(abi.encodePacked(did, commitmentHash, holder))
            .toEthSignedMessageHash();
        address signer = digest.recover(issuerSignature);

        if (!isAuthorizedIssuer[signer]) {
            revert InvalidIssuerSignature();
        }

        _records[did] = Credential({
            commitmentHash: commitmentHash,
            issuer: signer,
            holder: holder,
            timestamp: uint64(block.timestamp),
            status: Status.Active
        });

        emit IdentityRegistered(did, commitmentHash, signer, holder, uint64(block.timestamp));
    }

    // ---------------------------------------------------------------
    // Revocation — Section IV-D, "status updated exclusively through the
    // smart-contract function", Eq. (3)
    // ---------------------------------------------------------------

    /// @notice Revokes a previously registered identity credential.
    /// @dev Callable by either the original issuing authority or the holder
    ///      themselves (e.g., on key compromise), matching the revocation
    ///      transparency requirement discussed in Section VIII-A.
    function revokeIdentity(bytes32 did) external {
        Credential storage record = _records[did];

        if (record.status == Status.None) revert DidNotRegistered(did);
        if (record.status == Status.Revoked) revert AlreadyRevoked(did);
        if (msg.sender != record.issuer && msg.sender != record.holder) {
            revert NotAuthorizedToRevoke(did, msg.sender);
        }

        record.status = Status.Revoked;
        emit IdentityRevoked(did, msg.sender, uint64(block.timestamp));
    }

    // ---------------------------------------------------------------
    // Verification — Fig. 3 "On-Chain Proof Validation"
    // ---------------------------------------------------------------

    /// @notice Verifies that a presented commitment hash matches the on-chain
    ///         record for a DID and that the credential has not been revoked.
    /// @return valid True only if the DID is registered, active, and the
    ///                supplied commitment hash matches the stored value.
    function verifyIdentity(bytes32 did, bytes32 commitmentHash)
        external
        view
        returns (bool valid)
    {
        Credential memory record = _records[did];
        valid =
            record.status == Status.Active &&
            record.commitmentHash == commitmentHash;
    }

    /// @notice Returns the full on-chain record R = <DID, H, timestamp, status> for a DID.
    function getRecord(bytes32 did)
        external
        view
        returns (
            bytes32 commitmentHash,
            address issuer,
            address holder,
            uint64 timestamp,
            Status status
        )
    {
        Credential memory record = _records[did];
        if (record.status == Status.None) revert DidNotRegistered(did);
        return (record.commitmentHash, record.issuer, record.holder, record.timestamp, record.status);
    }
}
