const { expect } = require("chai");
const hre = require("hardhat");
const { ethers } = hre;
const { anyValue } = require("@nomicfoundation/hardhat-chai-matchers/withArgs");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const artifact = JSON.parse(
  fs.readFileSync(path.join(__dirname, "..", "artifacts-solc", "IdentityRegistry.json"), "utf8")
);

// ---- off-chain helpers, mirroring Section IV of the paper -----------------

/** Eq. (1): H = Hash(A1‖A2‖…‖An‖salt) */
function commitmentHash(attributes, salt) {
  const packed = ethers.solidityPackedKeccak256(
    ["string", "bytes32"],
    [JSON.stringify(attributes), salt]
  );
  return packed;
}

function randomSalt() {
  return "0x" + crypto.randomBytes(32).toString("hex");
}

function didFor(holderAddress, nonce) {
  return ethers.keccak256(ethers.solidityPacked(["address", "uint256"], [holderAddress, nonce]));
}

async function deployRegistry(owner) {
  const factory = new ethers.ContractFactory(artifact.abi, artifact.bytecode, owner);
  const contract = await factory.deploy(owner.address);
  await contract.waitForDeployment();
  return contract;
}

describe("IdentityRegistry (Secure Digital Identity Management on Blockchain)", function () {
  let owner, issuer, otherIssuer, holder, verifierEOA, attacker;
  let registry;

  beforeEach(async function () {
    [owner, issuer, otherIssuer, holder, verifierEOA, attacker] = await ethers.getSigners();
    registry = await deployRegistry(owner);
  });

  it("allows the owner to authorize an issuer (registrar role, Section V)", async function () {
    expect(await registry.isAuthorizedIssuer(issuer.address)).to.equal(false);
    await expect(registry.connect(owner).authorizeIssuer(issuer.address))
      .to.emit(registry, "IssuerAuthorized")
      .withArgs(issuer.address);
    expect(await registry.isAuthorizedIssuer(issuer.address)).to.equal(true);
  });

  it("rejects issuer authorization from a non-owner", async function () {
    await expect(registry.connect(attacker).authorizeIssuer(issuer.address)).to.be.reverted;
  });

  describe("registerIdentity — Fig. 4 registration flow", function () {
    let did, salt, hash;

    beforeEach(async function () {
      await registry.connect(owner).authorizeIssuer(issuer.address);
      did = didFor(holder.address, 1);
      salt = randomSalt();
      hash = commitmentHash({ name: "Alice", dob: "2000-01-01", nationalId: "X123456" }, salt);
    });

    async function signAsIssuer(signer, didArg, hashArg, holderAddress) {
      const digest = ethers.keccak256(
        ethers.solidityPacked(["bytes32", "bytes32", "address"], [didArg, hashArg, holderAddress])
      );
      // eth_sign style prefixed signature, matching MessageHashUtils.toEthSignedMessageHash
      return signer.signMessage(ethers.getBytes(digest));
    }

    it("registers a DID when signed by an authorized issuer, matching Eq. (2)/(3)", async function () {
      const sig = await signAsIssuer(issuer, did, hash, holder.address);

      await expect(registry.connect(holder).registerIdentity(did, hash, sig))
        .to.emit(registry, "IdentityRegistered")
        .withArgs(did, hash, issuer.address, holder.address, anyValue);

      const record = await registry.getRecord(did);
      expect(record.commitmentHash).to.equal(hash);
      expect(record.issuer).to.equal(issuer.address);
      expect(record.holder).to.equal(holder.address);
      expect(record.status).to.equal(1); // Active

      expect(await registry.verifyIdentity(did, hash)).to.equal(true);
    });

    it("rejects registration signed by an unauthorized issuer", async function () {
      const sig = await signAsIssuer(otherIssuer, did, hash, holder.address); // not authorized
      await expect(
        registry.connect(holder).registerIdentity(did, hash, sig)
      ).to.be.revertedWithCustomError(registry, "InvalidIssuerSignature");
    });

    it("prevents re-registering the same DID (duplicate identity)", async function () {
      const sig = await signAsIssuer(issuer, did, hash, holder.address);
      await registry.connect(holder).registerIdentity(did, hash, sig);

      const sig2 = await signAsIssuer(issuer, did, hash, holder.address);
      await expect(
        registry.connect(holder).registerIdentity(did, hash, sig2)
      ).to.be.revertedWithCustomError(registry, "DidAlreadyRegistered");
    });

    it("fails verification for a tampered commitment hash (integrity check)", async function () {
      const sig = await signAsIssuer(issuer, did, hash, holder.address);
      await registry.connect(holder).registerIdentity(did, hash, sig);

      const tamperedHash = commitmentHash({ name: "Mallory" }, salt);
      expect(await registry.verifyIdentity(did, tamperedHash)).to.equal(false);
    });
  });

  describe("revokeIdentity — Section IV-D revocation semantics", function () {
    let did, salt, hash;

    beforeEach(async function () {
      await registry.connect(owner).authorizeIssuer(issuer.address);
      did = didFor(holder.address, 42);
      salt = randomSalt();
      hash = commitmentHash({ name: "Bob", dob: "1995-05-05" }, salt);

      const digest = ethers.keccak256(
        ethers.solidityPacked(["bytes32", "bytes32", "address"], [did, hash, holder.address])
      );
      const sig = await issuer.signMessage(ethers.getBytes(digest));
      await registry.connect(holder).registerIdentity(did, hash, sig);
    });

    it("allows the issuer to revoke", async function () {
      await expect(registry.connect(issuer).revokeIdentity(did))
        .to.emit(registry, "IdentityRevoked")
        .withArgs(did, issuer.address, anyValue);

      expect(await registry.verifyIdentity(did, hash)).to.equal(false);
      const record = await registry.getRecord(did);
      expect(record.status).to.equal(2); // Revoked
    });

    it("allows the holder to self-revoke (e.g., on key compromise)", async function () {
      await registry.connect(holder).revokeIdentity(did);
      expect(await registry.verifyIdentity(did, hash)).to.equal(false);
    });

    it("rejects revocation from an unrelated third party", async function () {
      await expect(
        registry.connect(attacker).revokeIdentity(did)
      ).to.be.revertedWithCustomError(registry, "NotAuthorizedToRevoke");
    });

    it("rejects double revocation", async function () {
      await registry.connect(issuer).revokeIdentity(did);
      await expect(
        registry.connect(issuer).revokeIdentity(did)
      ).to.be.revertedWithCustomError(registry, "AlreadyRevoked");
    });
  });

  describe("verifyIdentity — Fig. 3 on-chain proof validation", function () {
    it("returns false for a DID that was never registered", async function () {
      const unknownDid = didFor(verifierEOA.address, 999);
      expect(await registry.verifyIdentity(unknownDid, ethers.ZeroHash)).to.equal(false);
    });
  });
});

